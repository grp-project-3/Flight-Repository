package com.flight.FlightProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
